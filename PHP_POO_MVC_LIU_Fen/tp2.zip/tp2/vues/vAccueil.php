<?php $this->titre = "Page d'accueil"; ?>


<p>Bienvenue sur ce site de gestion d'une bibliothèque</p>
