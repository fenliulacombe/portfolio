<?php $this->titre = "Page d'erreur"; ?>
<p class="erreur">Une erreur est survenue : <?= $msgErreur ?></p>
